
<div align="center">
  <img src="assets/menina-kawaii.png" alt="Menina ruiva kawaii" width="250"/>
</div>

## 🌸 Olá, eu sou a Mariana 🌸

🙏🏻 Deus acima de tudo  
🎓 Estudante de Engenharia de Software  
💻 Apaixonada por tecnologia  
📚 Sempre em busca de evolução!  

---

### 🛠️ Tecnologias que mais uso

![HTML5](https://img.shields.io/badge/-HTML5-E34F26?logo=html5&logoColor=fff&style=flat)
![CSS3](https://img.shields.io/badge/-CSS3-1572B6?logo=css3&logoColor=fff&style=flat)
![JavaScript](https://img.shields.io/badge/-JavaScript-F7DF1E?logo=javascript&logoColor=000&style=flat)
![Python](https://img.shields.io/badge/-Python-3776AB?logo=python&logoColor=fff&style=flat)

---

### 📈 GitHub Stats

![Mariana's GitHub stats](https://github-readme-stats.vercel.app/api?username=marianaargolozz&show_icons=true&theme=radical)  
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=marianaargolozz&layout=compact&theme=radical)](https://github.com/marianaargolozz)

---

### 📫 Vamos conversar?

- 💼 [LinkedIn](https://www.linkedin.com/in/mariana-argolo-208b87351/)

---

⭐️ Obrigada por visitar meu perfil! Sinta-se à vontade para explorar meus projetos e colaborar!
